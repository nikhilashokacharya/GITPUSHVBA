// import { shallowMount } from '@vue/test-utils'
// import UseButton from './index.vue'

// const id = 'UseButtonTest'

// const propsObj = {
//   tabIndex: -1,
//   disabled: false,
//   check: false,
//   outline: true,
//   id
// }

// const factory = (propsArg: Object) => {
//   return shallowMount(UseButton, {
//     propsData: {
//       // id,
//       ...propsObj,
//       ...propsArg
//     },
//     slots: {
//       default: id
//     }
//   })
// }

// describe('UseButton.vue', () => {
//   describe('render and default test', () => {
//     const testWrapper = factory(propsObj)
//     it('instance test', () => {
//       expect(testWrapper.isVueInstance()).toBe(true)
//     })
//   })
// })
