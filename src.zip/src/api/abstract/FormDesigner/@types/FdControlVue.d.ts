interface FdControlVue {
    propControlData: controlData
}
